const jwt = require('jsonwebtoken');

exports.auth= (req, res, next) => {
    try {
        const token = req.headers.jwttoken;
        const verified = jwt.verify(token, 'test');
        if(verified){
            next();
        }else{
            return res.status(401).send("token required");
        }
    } catch (error) {
        return res.status(401).send(error);
    }
};