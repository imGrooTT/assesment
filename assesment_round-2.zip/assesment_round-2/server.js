const express = require('express'); 
const app = express(); 
const http = require('http');

const server =  http.createServer(app);
const employee= require('./routes/empRoute');

require("./database/connection")

app.use(express.json());

app.use('/', employee);



server.listen(3000,(err)=>{
    if(!err){console.log("server started",3000)}
    else{
      console.log(err)
    }
});
