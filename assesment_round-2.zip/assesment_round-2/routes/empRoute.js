const express = require('express');
const router=express.Router();
const {generateToken}=require('../service/createToken');

const { createEmployee ,getallEmployees}=require('../apiController/empController')
const {auth} = require("../Auth/jwtAuth");

router.route("/generateToken").post(generateToken);

router.route("/addemployee").post(auth,createEmployee);

router.route("/getallEmployees").get(auth,getallEmployees);


module.exports = router;
