var mongoose = require('mongoose');
const {v4 : uuidv4} = require('uuid')

var data = mongoose.Schema({
    name: {
        type:String,
    },
    employeeId:{
        type:String,
        default:() => 'EM'+uuidv4(),
    }
});

let employeeSchema = mongoose.Schema({
    employeeDetail: {
        type:[data],
    }
});



module.exports = mongoose.model('employee',employeeSchema)
