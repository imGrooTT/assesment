const mongoose = require('mongoose');


const DB="mongodb+srv://abhishek:abhishek@cluster0.kepeh.mongodb.net/EmployeeDB?retryWrites=true&w=majority";

mongoose.connect(DB,{
    useNewUrlParser:true,
    useUnifiedTopology:true,
}).then(()=>{
    console.log("connection is successful");
}).catch((error) => console.log(`${error} did not connect`)
)

