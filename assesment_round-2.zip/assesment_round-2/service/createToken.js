const jwt = require('jsonwebtoken');

exports.generateToken= (req, res) => {
  
    let jwtSecretKey = 'test';
    let data = {
        time: Date(),
        userId: 12,
    }
  
    const token = jwt.sign(data, jwtSecretKey);
  
    res.send(token);
};