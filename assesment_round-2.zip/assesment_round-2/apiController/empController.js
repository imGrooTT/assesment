const employee= require('../models/employee');
const sendToken = require('../service/createToken');

exports.createEmployee= async(req,res)=>{
    try {
        let employeData = new employee(req.body);
        await employeData.save();
        res.status(201).send(employeData);
    } catch (error) {
        res.status(500).send(error)
    }
}

exports.getallEmployees = async(req,res)=>{
    try {
        let employeData = await employee.find();
        res.status(200).send(employeData);      
    } catch (error) {
        res.status(500).send(error)
    }
};